/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.6-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: mdim
-- ------------------------------------------------------
-- Server version	11.8.6-MariaDB-ubu2404

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `doctrine_migration_versions`
--

DROP TABLE IF EXISTS `doctrine_migration_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `doctrine_migration_versions` (
  `version` varchar(191) NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctrine_migration_versions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `doctrine_migration_versions` WRITE;
/*!40000 ALTER TABLE `doctrine_migration_versions` DISABLE KEYS */;
INSERT INTO `doctrine_migration_versions` VALUES
('DoctrineMigrations\\Version20260325142224','2026-03-25 18:36:42',68),
('DoctrineMigrations\\Version20260325142340','2026-03-25 18:36:42',30),
('DoctrineMigrations\\Version20260325150246','2026-03-25 18:36:42',5),
('DoctrineMigrations\\Version20260325150636','2026-03-25 18:36:42',142);
/*!40000 ALTER TABLE `doctrine_migration_versions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lle_credential_credential`
--

DROP TABLE IF EXISTS `lle_credential_credential`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lle_credential_credential` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(255) NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `section` varchar(255) NOT NULL,
  `visible` tinyint(4) DEFAULT 1,
  `status_list` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`status_list`)),
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=274 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lle_credential_credential`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lle_credential_credential` WRITE;
/*!40000 ALTER TABLE `lle_credential_credential` DISABLE KEYS */;
INSERT INTO `lle_credential_credential` VALUES
(183,'ROLE_USER','Menu ',NULL,'Menu',1,'[]','2026-03-25 18:38:51'),
(184,'ROLE_GROUP_INDEX','action.list','credential.action.show','GROUP',1,'[]','2026-03-25 18:38:51'),
(185,'ROLE_GROUP_SHOW','action.show','credential.action.item','GROUP',1,'[]','2026-03-25 18:38:51'),
(186,'ROLE_GROUP_EDIT','action.edit','credential.action.show','GROUP',1,'[]','2026-03-25 18:38:51'),
(187,'ROLE_GROUP_NEW','action.add','credential.action.list','GROUP',1,'[]','2026-03-25 18:38:51'),
(188,'ROLE_GROUP_DELETE','action.delete','credential.action.show','GROUP',1,'[]','2026-03-25 18:38:51'),
(189,'ROLE_GROUP_EXPORT','action.export','credential.action.list','GROUP',1,'[]','2026-03-25 18:38:51'),
(190,'ROLE_DASHBOARD_CHART_WIDGET','widget.charts.title','credential.widget','Widgets',1,'[]','2026-03-25 18:38:51'),
(191,'ROLE_DASHBOARD_POST_IT','widget.postit.title','credential.widget','Widgets',1,'[]','2026-03-25 18:38:51'),
(192,'ROLE_CREDENTIAL_ACTION_TOGGLEGROUP','action.credential.toggle_group','credential.action','CREDENTIAL',1,'[]','2026-03-25 18:38:51'),
(193,'ROLE_CREDENTIAL_ACTION_TOGGLERUBRIQUE','action.credential.toggle_rubrique','credential.action','CREDENTIAL',1,'[]','2026-03-25 18:38:51'),
(194,'ROLE_CREDENTIAL_ACTION_TOGGLECREDENTIAL','action.credential.toggle_credential','credential.action','CREDENTIAL',1,'[]','2026-03-25 18:38:51'),
(195,'ROLE_CREDENTIAL_ACTION_ALLOWSTATUS','action.credential.allow_status','credential.action','CREDENTIAL',1,'[]','2026-03-25 18:38:51'),
(196,'ROLE_ADMIN_USER','Menu menu-users',NULL,'Menu',1,'[]','2026-03-25 18:38:51'),
(197,'ROLE_USER_INDEX','action.list','credential.action.show','USER',1,'[]','2026-03-25 18:38:51'),
(198,'ROLE_USER_SHOW','action.show','credential.action.item','USER',1,'[]','2026-03-25 18:38:51'),
(199,'ROLE_USER_EDIT','action.edit','credential.action.show','USER',1,'[]','2026-03-25 18:38:51'),
(200,'ROLE_USER_NEW','action.add','credential.action.list','USER',1,'[]','2026-03-25 18:38:51'),
(201,'ROLE_USER_DELETE','action.delete','credential.action.show','USER',1,'[]','2026-03-25 18:38:51'),
(202,'ROLE_USER_EXPORT','action.export','credential.action.list','USER',1,'[]','2026-03-25 18:38:51'),
(203,'ROLE_ALLOWED_TO_SWITCH','action.impersonate','credential.action','USER',1,'[]','2026-03-25 18:38:51'),
(204,'ROLE_ADMIN_DROITS','↳ Sous menu credentials',NULL,'Menu',1,'[]','2026-03-25 18:38:51'),
(205,'ROLE_SETTINGS','Menu menu-settings',NULL,'Menu',1,'[]','2026-03-25 18:38:51'),
(206,'ROLE_PDFMODEL_INDEX','action.list','credential.action.show','PDFMODEL',1,'[]','2026-03-25 18:38:51'),
(207,'ROLE_PDFMODEL_SHOW','action.show','credential.action.item','PDFMODEL',1,'[]','2026-03-25 18:38:51'),
(208,'ROLE_PDFMODEL_EDIT','action.edit','credential.action.show','PDFMODEL',1,'[]','2026-03-25 18:38:51'),
(209,'ROLE_PDFMODEL_NEW','action.add','credential.action.list','PDFMODEL',1,'[]','2026-03-25 18:38:51'),
(210,'ROLE_PDFMODEL_DELETE','action.delete','credential.action.show','PDFMODEL',1,'[]','2026-03-25 18:38:51'),
(211,'ROLE_PDFMODEL_EXPORT','action.export','credential.action','PDFMODEL',1,'[]','2026-03-25 18:38:51'),
(212,'ROLE_HERMES_DASHBOARD','↳ Sous menu lle_hermes_dashboard',NULL,'Menu',1,'[]','2026-03-25 18:38:51'),
(213,'ROLE_HERMES_TEMPLATE_INDEX','action.list','credential.action.show','HERMES_TEMPLATE',1,'[]','2026-03-25 18:38:51'),
(214,'ROLE_HERMES_MAIL_INDEX','action.list','credential.action.show','HERMES_MAIL',1,'[]','2026-03-25 18:38:51'),
(215,'ROLE_HERMES_RECIPIENT_INDEX','action.list','credential.action.show','HERMES_RECIPIENT',1,'[]','2026-03-25 18:38:51'),
(216,'ROLE_HERMES_EMAILERROR_INDEX','↳ Sous menu lle_hermes_emailerror',NULL,'Menu',1,'[]','2026-03-25 18:38:51'),
(217,'ROLE_HERMES_UNSUBSCRIBEEMAIL_INDEX','↳ Sous menu lle_hermes_unsubscribeemail',NULL,'Menu',1,'[]','2026-03-25 18:38:51'),
(218,'ROLE_HERMES_EMAIL_ERROR_INDEX','action.list','credential.action.show','HERMES_EMAIL_ERROR',1,'[]','2026-03-25 18:38:51'),
(219,'ROLE_HERMES_EMAIL_ERROR_SHOW','action.show','credential.action.item','HERMES_EMAIL_ERROR',1,'[]','2026-03-25 18:38:51'),
(220,'ROLE_HERMES_EMAIL_ERROR_EDIT','action.edit','credential.action','HERMES_EMAIL_ERROR',1,'[]','2026-03-25 18:38:51'),
(221,'ROLE_HERMES_EMAIL_ERROR_NEW','action.add','credential.action','HERMES_EMAIL_ERROR',1,'[]','2026-03-25 18:38:51'),
(222,'ROLE_HERMES_EMAIL_ERROR_DELETE','action.delete','credential.action.show','HERMES_EMAIL_ERROR',1,'[]','2026-03-25 18:38:51'),
(223,'ROLE_HERMES_EMAIL_ERROR_EXPORT','action.export','credential.action.list','HERMES_EMAIL_ERROR',1,'[]','2026-03-25 18:38:51'),
(224,'ROLE_HERMES_ERROR_INDEX','action.list','credential.action.show','HERMES_ERROR',1,'[]','2026-03-25 18:38:51'),
(225,'ROLE_HERMES_ERROR_SHOW','action.show','credential.action.item','HERMES_ERROR',1,'[]','2026-03-25 18:38:51'),
(226,'ROLE_HERMES_ERROR_EDIT','action.edit','credential.action','HERMES_ERROR',1,'[]','2026-03-25 18:38:51'),
(227,'ROLE_HERMES_ERROR_NEW','action.add','credential.action.list','HERMES_ERROR',1,'[]','2026-03-25 18:38:51'),
(228,'ROLE_HERMES_ERROR_DELETE','action.delete','credential.action.show','HERMES_ERROR',1,'[]','2026-03-25 18:38:51'),
(229,'ROLE_HERMES_ERROR_EXPORT','action.export','credential.action.list','HERMES_ERROR',1,'[]','2026-03-25 18:38:51'),
(230,'ROLE_HERMES_LINK_INDEX','action.list','credential.action.show','HERMES_LINK',1,'[]','2026-03-25 18:38:51'),
(231,'ROLE_HERMES_LINK_SHOW','action.show','credential.action.item','HERMES_LINK',1,'[]','2026-03-25 18:38:51'),
(232,'ROLE_HERMES_LINK_EDIT','action.edit','credential.action','HERMES_LINK',1,'[]','2026-03-25 18:38:51'),
(233,'ROLE_HERMES_LINK_NEW','action.add','credential.action.list','HERMES_LINK',1,'[]','2026-03-25 18:38:51'),
(234,'ROLE_HERMES_LINK_DELETE','action.delete','credential.action','HERMES_LINK',1,'[]','2026-03-25 18:38:51'),
(235,'ROLE_HERMES_LINK_EXPORT','action.export','credential.action.list','HERMES_LINK',1,'[]','2026-03-25 18:38:51'),
(236,'ROLE_HERMES_LINK_OPENING_INDEX','action.list','credential.action.show','HERMES_LINK_OPENING',1,'[]','2026-03-25 18:38:51'),
(237,'ROLE_HERMES_LINK_OPENING_SHOW','action.show','credential.action.item','HERMES_LINK_OPENING',1,'[]','2026-03-25 18:38:51'),
(238,'ROLE_HERMES_LINK_OPENING_EDIT','action.edit','credential.action','HERMES_LINK_OPENING',1,'[]','2026-03-25 18:38:51'),
(239,'ROLE_HERMES_LINK_OPENING_NEW','action.add','credential.action.list','HERMES_LINK_OPENING',1,'[]','2026-03-25 18:38:51'),
(240,'ROLE_HERMES_LINK_OPENING_DELETE','action.delete','credential.action','HERMES_LINK_OPENING',1,'[]','2026-03-25 18:38:51'),
(241,'ROLE_HERMES_LINK_OPENING_EXPORT','action.export','credential.action.list','HERMES_LINK_OPENING',1,'[]','2026-03-25 18:38:51'),
(242,'ROLE_HERMES_MAIL_SHOW','action.show','credential.action.item','HERMES_MAIL',1,'[]','2026-03-25 18:38:51'),
(243,'ROLE_HERMES_MAIL_EDIT','action.edit','credential.action.show','HERMES_MAIL',1,'[]','2026-03-25 18:38:51'),
(244,'ROLE_HERMES_MAIL_NEW','action.add','credential.action','HERMES_MAIL',1,'[]','2026-03-25 18:38:51'),
(245,'ROLE_HERMES_MAIL_DELETE','action.delete','credential.action.show','HERMES_MAIL',1,'[]','2026-03-25 18:38:51'),
(246,'ROLE_HERMES_MAIL_EXPORT','action.export','credential.action.list','HERMES_MAIL',1,'[]','2026-03-25 18:38:51'),
(247,'ROLE_HERMES_MAIL_SEND','action.send','credential.action.show','HERMES_MAIL',1,'[]','2026-03-25 18:38:51'),
(248,'ROLE_HERMES_MAIL_SENDTESTMAIL','action.sendmailtest','credential.action.show','HERMES_MAIL',1,'[]','2026-03-25 18:38:51'),
(249,'ROLE_HERMES_MAIL_CANCEL','action.cancel','credential.action.show','HERMES_MAIL',1,'[]','2026-03-25 18:38:51'),
(250,'ROLE_HERMES_PERSONALIZED_TEMPLATE_INDEX','action.list','credential.action.show','HERMES_PERSONALIZED_TEMPLATE',1,'[]','2026-03-25 18:38:51'),
(251,'ROLE_HERMES_PERSONALIZED_TEMPLATE_SHOW','action.show','credential.action.item','HERMES_PERSONALIZED_TEMPLATE',1,'[]','2026-03-25 18:38:51'),
(252,'ROLE_HERMES_PERSONALIZED_TEMPLATE_EDIT','action.edit','credential.action.show','HERMES_PERSONALIZED_TEMPLATE',1,'[]','2026-03-25 18:38:51'),
(253,'ROLE_HERMES_PERSONALIZED_TEMPLATE_NEW','action.add','credential.action.list','HERMES_PERSONALIZED_TEMPLATE',1,'[]','2026-03-25 18:38:51'),
(254,'ROLE_HERMES_PERSONALIZED_TEMPLATE_DELETE','action.delete','credential.action.show','HERMES_PERSONALIZED_TEMPLATE',1,'[]','2026-03-25 18:38:51'),
(255,'ROLE_HERMES_PERSONALIZED_TEMPLATE_EXPORT','action.export','credential.action.list','HERMES_PERSONALIZED_TEMPLATE',1,'[]','2026-03-25 18:38:51'),
(256,'ROLE_HERMES_RECIPIENT_SHOW','action.show','credential.action.item','HERMES_RECIPIENT',1,'[]','2026-03-25 18:38:51'),
(257,'ROLE_HERMES_RECIPIENT_EDIT','action.edit','credential.action','HERMES_RECIPIENT',1,'[]','2026-03-25 18:38:51'),
(258,'ROLE_HERMES_RECIPIENT_NEW','action.add','credential.action','HERMES_RECIPIENT',1,'[]','2026-03-25 18:38:51'),
(259,'ROLE_HERMES_RECIPIENT_DELETE','action.delete','credential.action','HERMES_RECIPIENT',1,'[]','2026-03-25 18:38:51'),
(260,'ROLE_HERMES_RECIPIENT_EXPORT','action.export','credential.action.list','HERMES_RECIPIENT',1,'[]','2026-03-25 18:38:51'),
(261,'ROLE_HERMES_RECIPIENT_RESEND','action.resend','credential.action.show','HERMES_RECIPIENT',1,'[]','2026-03-25 18:38:51'),
(262,'ROLE_HERMES_TEMPLATE_SHOW','action.show','credential.action.item','HERMES_TEMPLATE',1,'[]','2026-03-25 18:38:51'),
(263,'ROLE_HERMES_TEMPLATE_EDIT','action.edit','credential.action.show','HERMES_TEMPLATE',1,'[]','2026-03-25 18:38:51'),
(264,'ROLE_HERMES_TEMPLATE_NEW','action.add','credential.action.list','HERMES_TEMPLATE',1,'[]','2026-03-25 18:38:51'),
(265,'ROLE_HERMES_TEMPLATE_DELETE','action.delete','credential.action.show','HERMES_TEMPLATE',1,'[]','2026-03-25 18:38:51'),
(266,'ROLE_HERMES_TEMPLATE_EXPORT','action.export','credential.action.list','HERMES_TEMPLATE',1,'[]','2026-03-25 18:38:51'),
(267,'ROLE_HERMES_TEMPLATE_DUPLICATE','crud.action.duplicate','credential.action.item','HERMES_TEMPLATE',1,'[]','2026-03-25 18:38:51'),
(268,'ROLE_HERMES_UNSUBSCRIBE_EMAIL_INDEX','action.list','credential.action.show','HERMES_UNSUBSCRIBE_EMAIL',1,'[]','2026-03-25 18:38:51'),
(269,'ROLE_HERMES_UNSUBSCRIBE_EMAIL_SHOW','action.show','credential.action.item','HERMES_UNSUBSCRIBE_EMAIL',1,'[]','2026-03-25 18:38:51'),
(270,'ROLE_HERMES_UNSUBSCRIBE_EMAIL_EDIT','action.edit','credential.action','HERMES_UNSUBSCRIBE_EMAIL',1,'[]','2026-03-25 18:38:51'),
(271,'ROLE_HERMES_UNSUBSCRIBE_EMAIL_NEW','action.add','credential.action','HERMES_UNSUBSCRIBE_EMAIL',1,'[]','2026-03-25 18:38:51'),
(272,'ROLE_HERMES_UNSUBSCRIBE_EMAIL_DELETE','action.delete','credential.action.show','HERMES_UNSUBSCRIBE_EMAIL',1,'[]','2026-03-25 18:38:51'),
(273,'ROLE_HERMES_UNSUBSCRIBE_EMAIL_EXPORT','action.export','credential.action.list','HERMES_UNSUBSCRIBE_EMAIL',1,'[]','2026-03-25 18:38:51');
/*!40000 ALTER TABLE `lle_credential_credential` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lle_credential_group`
--

DROP TABLE IF EXISTS `lle_credential_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lle_credential_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `is_role` tinyint(4) NOT NULL,
  `active` tinyint(4) NOT NULL,
  `required_role` varchar(255) NOT NULL,
  `rank` int(11) NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lle_credential_group`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lle_credential_group` WRITE;
/*!40000 ALTER TABLE `lle_credential_group` DISABLE KEYS */;
INSERT INTO `lle_credential_group` VALUES
(1,'SUPER_ADMIN',1,1,'',1,'Super Administrateur');
/*!40000 ALTER TABLE `lle_credential_group` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lle_credential_group_credential`
--

DROP TABLE IF EXISTS `lle_credential_group_credential`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lle_credential_group_credential` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `allowed` tinyint(4) NOT NULL,
  `status_allowed` tinyint(4) DEFAULT 0,
  `credential_id` int(11) NOT NULL,
  `groupe_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `groupe_cred_unique_idx` (`groupe_id`,`credential_id`),
  KEY `IDX_46B0447A2558A7A5` (`credential_id`),
  KEY `IDX_46B0447A7A45358C` (`groupe_id`),
  CONSTRAINT `FK_46B0447A2558A7A5` FOREIGN KEY (`credential_id`) REFERENCES `lle_credential_credential` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_46B0447A7A45358C` FOREIGN KEY (`groupe_id`) REFERENCES `lle_credential_group` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lle_credential_group_credential`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lle_credential_group_credential` WRITE;
/*!40000 ALTER TABLE `lle_credential_group_credential` DISABLE KEYS */;
/*!40000 ALTER TABLE `lle_credential_group_credential` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lle_entity_file`
--

DROP TABLE IF EXISTS `lle_entity_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lle_entity_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entity_id` int(11) NOT NULL,
  `config_name` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `path` varchar(255) NOT NULL,
  `mime_type` varchar(255) NOT NULL,
  `size` double NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entity_id` (`entity_id`),
  KEY `idx_config_name` (`config_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lle_entity_file`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lle_entity_file` WRITE;
/*!40000 ALTER TABLE `lle_entity_file` DISABLE KEYS */;
/*!40000 ALTER TABLE `lle_entity_file` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lle_hermes_email_error`
--

DROP TABLE IF EXISTS `lle_hermes_email_error`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lle_hermes_email_error` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nb_error` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lle_hermes_email_error`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lle_hermes_email_error` WRITE;
/*!40000 ALTER TABLE `lle_hermes_email_error` DISABLE KEYS */;
/*!40000 ALTER TABLE `lle_hermes_email_error` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lle_hermes_error`
--

DROP TABLE IF EXISTS `lle_hermes_error`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lle_hermes_error` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `subject` varchar(1024) NOT NULL,
  `content` longtext DEFAULT NULL,
  `email_error_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_20767CE08806979E` (`email_error_id`),
  CONSTRAINT `FK_20767CE08806979E` FOREIGN KEY (`email_error_id`) REFERENCES `lle_hermes_email_error` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lle_hermes_error`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lle_hermes_error` WRITE;
/*!40000 ALTER TABLE `lle_hermes_error` DISABLE KEYS */;
/*!40000 ALTER TABLE `lle_hermes_error` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lle_hermes_link`
--

DROP TABLE IF EXISTS `lle_hermes_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lle_hermes_link` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `mail_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_9AF2B97EC8776F01` (`mail_id`),
  CONSTRAINT `FK_9AF2B97EC8776F01` FOREIGN KEY (`mail_id`) REFERENCES `lle_hermes_mail` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lle_hermes_link`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lle_hermes_link` WRITE;
/*!40000 ALTER TABLE `lle_hermes_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `lle_hermes_link` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lle_hermes_link_opening`
--

DROP TABLE IF EXISTS `lle_hermes_link_opening`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lle_hermes_link_opening` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nb_openings` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `link_id` int(11) DEFAULT NULL,
  `recipient_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_B5A63BCCADA40271` (`link_id`),
  KEY `IDX_B5A63BCCE92F8F78` (`recipient_id`),
  CONSTRAINT `FK_B5A63BCCADA40271` FOREIGN KEY (`link_id`) REFERENCES `lle_hermes_link` (`id`),
  CONSTRAINT `FK_B5A63BCCE92F8F78` FOREIGN KEY (`recipient_id`) REFERENCES `lle_hermes_recipient` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lle_hermes_link_opening`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lle_hermes_link_opening` WRITE;
/*!40000 ALTER TABLE `lle_hermes_link_opening` DISABLE KEYS */;
/*!40000 ALTER TABLE `lle_hermes_link_opening` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lle_hermes_mail`
--

DROP TABLE IF EXISTS `lle_hermes_mail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lle_hermes_mail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_name` varchar(255) DEFAULT NULL,
  `sender_email` varchar(255) DEFAULT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`data`)),
  `status` varchar(255) NOT NULL,
  `total_to_send` int(11) NOT NULL,
  `total_sended` int(11) NOT NULL,
  `subject` varchar(1024) NOT NULL,
  `sending_date` datetime DEFAULT NULL,
  `send_at_date` datetime DEFAULT NULL,
  `text` longtext DEFAULT NULL,
  `html` longtext DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `total_unsubscribed` int(11) NOT NULL,
  `total_error` int(11) NOT NULL,
  `attachement` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`attachement`)),
  `total_opened` int(11) NOT NULL,
  `tenant_id` int(11) DEFAULT NULL,
  `dsn` varchar(255) DEFAULT NULL,
  `attachments_deleted` tinyint(4) NOT NULL DEFAULT 0,
  `entity_class` varchar(255) DEFAULT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `mjml` longtext DEFAULT NULL,
  `template_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_FD788CC75DA0FB8` (`template_id`),
  KEY `tenant_id_idx` (`tenant_id`),
  KEY `entity_idx` (`entity_class`,`entity_id`),
  CONSTRAINT `FK_FD788CC75DA0FB8` FOREIGN KEY (`template_id`) REFERENCES `lle_hermes_template` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lle_hermes_mail`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lle_hermes_mail` WRITE;
/*!40000 ALTER TABLE `lle_hermes_mail` DISABLE KEYS */;
/*!40000 ALTER TABLE `lle_hermes_mail` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lle_hermes_recipient`
--

DROP TABLE IF EXISTS `lle_hermes_recipient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lle_hermes_recipient` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `to_name` varchar(255) DEFAULT NULL,
  `to_email` varchar(255) NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`data`)),
  `status` varchar(255) NOT NULL,
  `open_date` datetime DEFAULT NULL,
  `test` tinyint(4) NOT NULL,
  `tenant_id` int(11) DEFAULT NULL,
  `error_message` longtext DEFAULT NULL,
  `mail_id` int(11) DEFAULT NULL,
  `cc_mail_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_9F10836BC8776F01` (`mail_id`),
  KEY `IDX_9F10836B65A93B71` (`cc_mail_id`),
  KEY `tenant_id_idx` (`tenant_id`),
  CONSTRAINT `FK_9F10836B65A93B71` FOREIGN KEY (`cc_mail_id`) REFERENCES `lle_hermes_mail` (`id`),
  CONSTRAINT `FK_9F10836BC8776F01` FOREIGN KEY (`mail_id`) REFERENCES `lle_hermes_mail` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lle_hermes_recipient`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lle_hermes_recipient` WRITE;
/*!40000 ALTER TABLE `lle_hermes_recipient` DISABLE KEYS */;
/*!40000 ALTER TABLE `lle_hermes_recipient` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lle_hermes_template`
--

DROP TABLE IF EXISTS `lle_hermes_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lle_hermes_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) NOT NULL,
  `subject` varchar(1024) NOT NULL,
  `sender_name` varchar(255) DEFAULT NULL,
  `sender_email` varchar(255) NOT NULL,
  `text` longtext DEFAULT NULL,
  `code` varchar(255) NOT NULL,
  `html` longtext DEFAULT NULL,
  `unsubscriptions` tinyint(4) NOT NULL DEFAULT 0,
  `statistics` tinyint(4) NOT NULL DEFAULT 0,
  `send_to_errors` tinyint(4) NOT NULL DEFAULT 0,
  `tenant_id` int(11) DEFAULT NULL,
  `custom_bounce_email` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'html',
  `mjml` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tenant_id_idx` (`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lle_hermes_template`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lle_hermes_template` WRITE;
/*!40000 ALTER TABLE `lle_hermes_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `lle_hermes_template` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lle_hermes_unsubscribe_email`
--

DROP TABLE IF EXISTS `lle_hermes_unsubscribe_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lle_hermes_unsubscribe_email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `unsubscribe_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lle_hermes_unsubscribe_email`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lle_hermes_unsubscribe_email` WRITE;
/*!40000 ALTER TABLE `lle_hermes_unsubscribe_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `lle_hermes_unsubscribe_email` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lle_pdf_model`
--

DROP TABLE IF EXISTS `lle_pdf_model`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lle_pdf_model` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `path` varchar(255) NOT NULL,
  `libelle` varchar(255) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `datamodel` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `check_file` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lle_pdf_model`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lle_pdf_model` WRITE;
/*!40000 ALTER TABLE `lle_pdf_model` DISABLE KEYS */;
/*!40000 ALTER TABLE `lle_pdf_model` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(180) NOT NULL,
  `email` varchar(255) NOT NULL,
  `prenom` varchar(255) DEFAULT NULL,
  `nom` varchar(255) DEFAULT NULL,
  `actif` tinyint(4) NOT NULL DEFAULT 1,
  `connect_id` int(11) DEFAULT NULL,
  `roles` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`roles`)),
  `profil_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_IDENTIFIER_USERNAME` (`username`),
  UNIQUE KEY `UNIQ_IDENTIFIER_EMAIL` (`email`),
  KEY `IDX_8D93D649275ED078` (`profil_id`),
  CONSTRAINT `FK_8D93D649275ED078` FOREIGN KEY (`profil_id`) REFERENCES `lle_credential_group` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES
(1,'admin','dev@2le.net',NULL,NULL,1,1,'[\"ROLE_SUPER_ADMIN\",\"ROLE_USER\"]',1);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `x` int(11) DEFAULT NULL,
  `y` int(11) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `config` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`config`)),
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-03-25 18:06:40
